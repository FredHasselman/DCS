These are notes about the data files for Applied Longitudinal Data Analysis: Modeling Change and Event Occurrence by Judith D. Singer and John B. Willett.

Please note that the "early_int" data file (which is used in Chapter 3) is not included among the data files.  This was done at the request of the researcher who contributed this data file to ensure the privacy of the participants in the study. Although the web page shows how to obtain the results with this data file, we regret that visitors do not have access to this file to be able to replicate the results for themselves.
